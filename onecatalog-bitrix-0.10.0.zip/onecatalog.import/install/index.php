<?php

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ModuleManager;
use Bitrix\Main\Application;
use Bitrix\Main\Config\Option;

Loc::loadMessages(__FILE__);

if (class_exists('onecatalog_import')) {
    return;
}

/**
 * Манифест модуля OneCatalog Import (1С-Битрикс).
 *
 * Слой "Plugin" стандарта (§4): сборка, жизненный цикл, миграции.
 * Зависимость от движка магазина (§10): без iblock+catalog установка не падает,
 * а корректно сообщает об ошибке.
 */
class onecatalog_import extends CModule
{
    public $MODULE_ID = 'onecatalog.import';
    public $MODULE_VERSION;
    public $MODULE_VERSION_DATE;
    public $MODULE_NAME;
    public $MODULE_DESCRIPTION;
    public $MODULE_GROUP_RIGHTS = 'Y';
    public $PARTNER_NAME;
    public $PARTNER_URI = 'https://onecatalog.net';

    public function __construct()
    {
        $arModuleVersion = [];
        include __DIR__ . '/version.php';

        $this->MODULE_VERSION = $arModuleVersion['VERSION'];
        $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
        $this->MODULE_NAME = Loc::getMessage('ONECATALOG_IMPORT_MODULE_NAME');
        $this->MODULE_DESCRIPTION = Loc::getMessage('ONECATALOG_IMPORT_MODULE_DESC');
        $this->PARTNER_NAME = Loc::getMessage('ONECATALOG_IMPORT_PARTNER_NAME');
    }

    public function DoInstall()
    {
        global $APPLICATION;

        // Зависимость от движка магазина (§10): iblock + catalog обязательны.
        if (!$this->checkDependencies()) {
            $APPLICATION->ThrowException(Loc::getMessage('ONECATALOG_IMPORT_ERR_DEPENDENCIES'));
            return false;
        }

        ModuleManager::registerModule($this->MODULE_ID);

        $this->InstallDB();
        $this->InstallEvents();
        $this->InstallFiles();
        $this->setDefaultOptions();

        // Фоновый агент-обработчик очереди (фолбэк к AJAX-степперу, §6).
        \CAgent::AddAgent(
            "\\OneCatalog\\Import\\Queue::agent();",
            $this->MODULE_ID,
            'N',
            300, // каждые 5 минут
            '',
            'Y'
        );

        $APPLICATION->IncludeAdminFile(
            Loc::getMessage('ONECATALOG_IMPORT_INSTALL_TITLE'),
            __DIR__ . '/step.php'
        );

        return true;
    }

    public function DoUninstall()
    {
        global $APPLICATION;

        $keepData = ($_REQUEST['savedata'] ?? 'Y') === 'Y';

        \CAgent::RemoveModuleAgents($this->MODULE_ID);
        $this->UnInstallEvents();
        $this->UnInstallFiles();

        if (!$keepData) {
            $this->UnInstallDB();
            $this->deleteOptions();
        }

        ModuleManager::unRegisterModule($this->MODULE_ID);

        $APPLICATION->IncludeAdminFile(
            Loc::getMessage('ONECATALOG_IMPORT_UNINSTALL_TITLE'),
            __DIR__ . '/unstep.php'
        );

        return true;
    }

    /**
     * Таблицы трекинга очереди (oc_queue) и медиа/дедупа (oc_media) — §5.3, §6.
     * У CFile нет места под мету → своя таблица обязательна (блокер 6).
     */
    public function InstallDB()
    {
        $connection = Application::getConnection();

        if (!$connection->isTableExists('onecatalog_queue')) {
            $connection->queryExecute(
                "CREATE TABLE onecatalog_queue (
                    ID int(11) NOT NULL AUTO_INCREMENT,
                    BATCH int(11) NOT NULL DEFAULT 0,
                    PUBLIC_ID varchar(64) NOT NULL,
                    STATUS varchar(16) NOT NULL DEFAULT 'pending',
                    MESSAGE text NULL,
                    CREATED_AT datetime NOT NULL,
                    UPDATED_AT datetime NULL,
                    PRIMARY KEY (ID),
                    INDEX ix_oc_queue_status (STATUS),
                    INDEX ix_oc_queue_public (PUBLIC_ID)
                )"
            );
        }

        if (!$connection->isTableExists('onecatalog_media')) {
            $connection->queryExecute(
                "CREATE TABLE onecatalog_media (
                    ID int(11) NOT NULL AUTO_INCREMENT,
                    CONTENT_KEY varchar(64) NOT NULL,
                    SIZE varchar(8) NOT NULL DEFAULT 'min',
                    FILE_ID int(11) NOT NULL,
                    SHARED char(1) NOT NULL DEFAULT 'N',
                    CREATED_AT datetime NOT NULL,
                    PRIMARY KEY (ID),
                    UNIQUE INDEX ux_oc_media_key (CONTENT_KEY)
                )"
            );
        }

        // «Отстойник» (staging) для unknown-товаров B2B-фида (§13.5) — ручной отбор.
        if (!$connection->isTableExists('onecatalog_b2b_staging')) {
            $connection->queryExecute(
                "CREATE TABLE onecatalog_b2b_staging (
                    ID int(11) NOT NULL AUTO_INCREMENT,
                    SUPPLIER_ID int(11) NULL,
                    CODE varchar(128) NOT NULL,
                    NAME varchar(512) NULL,
                    DATA longtext NULL,
                    STATUS varchar(16) NOT NULL DEFAULT 'new',
                    CREATED_AT datetime NOT NULL,
                    UPDATED_AT datetime NULL,
                    PRIMARY KEY (ID),
                    UNIQUE INDEX ux_oc_staging (SUPPLIER_ID, CODE),
                    INDEX ix_oc_staging_status (STATUS)
                )"
            );
        }

        // Служебные значения по элементам (сигнатуры идемпотентности, коды поставщиков),
        // чтобы не засорять форму товара свойствами инфоблока.
        if (!$connection->isTableExists('onecatalog_meta')) {
            $connection->queryExecute(
                "CREATE TABLE onecatalog_meta (
                    ID int(11) NOT NULL AUTO_INCREMENT,
                    ELEMENT_ID int(11) NOT NULL,
                    META_KEY varchar(50) NOT NULL,
                    VALUE longtext NULL,
                    PRIMARY KEY (ID),
                    UNIQUE INDEX ux_oc_meta (ELEMENT_ID, META_KEY)
                )"
            );
        }

        return true;
    }

    public function UnInstallDB()
    {
        $connection = Application::getConnection();
        foreach (['onecatalog_queue', 'onecatalog_media', 'onecatalog_meta', 'onecatalog_b2b_staging'] as $table) {
            if ($connection->isTableExists($table)) {
                $connection->dropTable($table);
            }
        }
        return true;
    }

    public function InstallEvents()
    {
        // Колонка OneCatalog ID в списке товаров (украшение ячейки OC_PUBLIC_ID).
        \RegisterModuleDependences('main', 'OnAdminListDisplay', $this->MODULE_ID, 'OneCatalog\\Import\\AdminColumn', 'onAdminListDisplay');
        return true;
    }

    public function UnInstallEvents()
    {
        \UnRegisterModuleDependences('main', 'OnAdminListDisplay', $this->MODULE_ID, 'OneCatalog\\Import\\AdminColumn', 'onAdminListDisplay');
        return true;
    }

    public function InstallFiles()
    {
        // Admin-страницы (обёртки) → /bitrix/admin; JS виджета/степпера → /bitrix/js.
        CopyDirFiles(__DIR__ . '/admin', $_SERVER['DOCUMENT_ROOT'] . '/bitrix/admin', true, true);
        CopyDirFiles(__DIR__ . '/js', $_SERVER['DOCUMENT_ROOT'] . '/bitrix/js', true, true);
        return true;
    }

    public function UnInstallFiles()
    {
        DeleteDirFiles(__DIR__ . '/admin', $_SERVER['DOCUMENT_ROOT'] . '/bitrix/admin');
        DeleteDirFiles(__DIR__ . '/js', $_SERVER['DOCUMENT_ROOT'] . '/bitrix/js');
        return true;
    }

    private function checkDependencies(): bool
    {
        return ModuleManager::isModuleInstalled('iblock')
            && ModuleManager::isModuleInstalled('catalog');
    }

    /**
     * Дефолты настроек (§7). Кламп/валидация — в слое Settings.
     */
    private function setDefaultOptions(): void
    {
        $defaults = [
            'API_BASE_URL'          => 'https://api.onecatalog.net/wiki/v1',
            'API_TOKEN'             => '',
            'PICKER_BASE'           => 'https://tools.onecatalog.net',
            'LANG'                  => 'en',
            'STEP'                  => '10',
            'NEW_ACTIVE'            => 'Y',
            // Справочные сущности по умолчанию ВЫКЛючены — включаются осознанно,
            // после выбора целевого поля (нативное/существующее свойство или своё).
            'IMPORT_COLLECTIONS'    => 'N',
            'COLLECTION_TARGET_TYPE'=> 'list',  // реализован адаптер «список»; iblock/раздел — opt-in
            'IMPORT_BRAND'          => 'N',
            'BRAND_TARGET_TYPE'     => 'list',   // дефолт — список (L), не HL (в.10)
            'IMPORT_COUNTRY'        => 'N',
            'COUNTRY_TARGET_TYPE'   => 'list',
            'IMPORT_TAGS'           => 'N',
            // Целевое свойство справочных сущностей: пусто = авто-создание своего
            // списка (OC_*); иначе — код существующего свойства-списка инфоблока.
            'BRAND_PROP_CODE'       => '',
            'COUNTRY_PROP_CODE'     => '',
            'COLLECTION_PROP_CODE'  => '',
            'SPEC_MANUAL_MAPPING'   => 'N',
            'CATALOG_IBLOCK_ID'     => '',
            // B2B: цены и остатки (§13)
            'B2B_BASE_URL'          => 'https://api.onecatalog.net/b2b/v1',
            'B2B_KEY'               => '',
            'B2B_PRIVATE_KEY'       => '',
            'B2B_PRICE_STRATEGY'    => 'min',
            'B2B_PROMO_AS_SALE'     => 'Y',
            'B2B_PROMO_GROUP'       => '0',
            'B2B_DECIMAL_STOCK'     => 'Y',
            'B2B_USE_STORES'        => 'N',
            'B2B_PAGE_SIZE'         => '200',
            'B2B_NOTIFY'            => 'Y',
        ];
        foreach ($defaults as $name => $value) {
            if (Option::get('onecatalog.import', $name, null) === null) {
                Option::set('onecatalog.import', $name, $value);
            }
        }
    }

    private function deleteOptions(): void
    {
        Option::delete('onecatalog.import');
    }
}
